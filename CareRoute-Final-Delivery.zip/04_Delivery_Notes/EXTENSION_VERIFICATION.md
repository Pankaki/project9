# Widget / Share Extension Verification

Date: 30 September 2026

## Checks completed

The repeatable command below was run against the Xcode 15.2 iOS 17.2 Simulator build:

```bash
scripts/verify_extensions.sh
```

It passed the following checks:

- `CareRouteWidget.appex` is embedded in `CareRoute.app`.
- `CareRouteShareExtension.appex` is embedded in `CareRoute.app`.
- Both extension Info.plist files pass `plutil -lint`.
- WidgetKit extension point is `com.apple.widgetkit-extension`.
- Share Extension point is `com.apple.share-services`.
- Widget declares `systemSmall` and `systemMedium`.
- Widget reads `WidgetSnapshot` from the shared bridge.
- Share Extension accepts text and web URLs.
- Share Extension writes a `SharedReferral` and calls `completeRequest`.
- Host app installs and launches on the iPhone 15 Simulator.
- The host app generated a route containing the seeded patients and visits.

## Simulator evidence

The host app was seeded with three patients and three visits. The Today screen displayed two visits scheduled for 30 September 2026, including patient names, time, purpose, address, priority, and Scheduled status. This confirms the production Core Data route and the Widget snapshot source data are available to the host app.

## Remaining signing-dependent step

The local machine has no valid Apple code-signing identity (`security find-identity -v -p codesigning` reports zero identities). The local simulator build is therefore unsigned/ad-hoc and `simctl listapps` reports no provisioned App Group container. As a result, the following two actions cannot honestly be claimed as completed on this machine:

1. Add the CareRoute Widget to the simulator Home Screen and verify that the WidgetKit process reads the same App Group snapshot.
2. Open Safari's system Share Sheet, select CareRoute, and verify the Share Extension writes into the same App Group container that the main app reads.

The source, entitlements, extension registration, activation rules, and data-flow code are present and verified. To finish the true end-to-end check, open the project on a Mac with an Apple development team selected, enable the same App Group for all three targets, build with signing enabled, then perform the two user flows above.

This limitation is explicitly documented rather than presented as a false end-to-end result.
