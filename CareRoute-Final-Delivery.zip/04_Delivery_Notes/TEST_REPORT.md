# CareRoute Test Report

## Environment

- Xcode: 15.2
- iOS Simulator runtime: iOS 17.2
- Device: iPhone 15 Simulator
- Bundle identifier: `com.example.CareRoute`
- Build mode: Debug, `iphonesimulator`, code signing disabled for local simulator validation

## Automated validation

- Portable domain tests: **7 passed, 0 failed**.
- Submission audit: **PASS**.
- Delivery verification: **PASS**.
- Required PDF: 7 pages; reflective report verified at 800 words.
- Xcode build: **BUILD SUCCEEDED**.

## Simulator validation

The application was installed, launched, terminated, and relaunched on the iPhone 15 Simulator. Core Data data remained available after relaunch and the Today route displayed the seeded visits.

Seeded records in the simulator:

- 3 patients: Maya Chen, Thomas Wilson, Aisha Patel.
- 3 scheduled home visits, including two for the current route and one future visit.
- 1 care note.
- Priority values exercised: Important, Routine, and Urgent.

The screenshot in this folder shows the Today route with the seeded visit cards.

## Known submission checks

- A physical-device build requires a valid Apple developer team and signing configuration.
- WidgetKit and Share Extension source and App Group wiring are included in the Xcode project. Before final academic submission, verify the WidgetKit refresh and Share Sheet import end-to-end with signing enabled.
- The assessment also requests a GitHub/GitLab link, feature branches, and Conventional Commits. The local delivery package does not invent a repository URL; add the real repository link before submitting.
