# CareRoute Final Delivery Manifest

## Contents

| Folder | Contents |
|---|---|
| `01_Required_Document` | The single required assessment PDF containing the problem statement, design justification, architecture diagram, and reflective report. |
| `02_Xcode_Project` | `CareRoute-submission.zip`, containing the Xcode project, app, Core Data layer, WidgetKit extension, Share Extension, tests, README, scripts, and documentation. |
| `03_Test_Evidence` | Screenshot of the running iPhone 15 Simulator with seeded route data. |
| `04_Delivery_Notes` | Test report, validation results, seeded-data details, and remaining submission checks. |

## Primary files

- Required PDF: `01_Required_Document/CareRoute_Required_Document.pdf`
- Xcode project archive: `02_Xcode_Project/CareRoute-submission.zip`
- Test report: `04_Delivery_Notes/TEST_REPORT.md`

## Important before submission

The assessment requires a GitHub or GitLab repository link, feature branches, and Conventional Commits. Add the actual repository URL to the submission form/README before submitting. No credentials or Apple ID information are included in this delivery package.
